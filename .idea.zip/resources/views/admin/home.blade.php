@extends('base.admin')

@section('title', 'Bosh sahifa')

@section('content_name', 'Bosh sahifa')

@section('main_content')

    Assalomu aleykum

@endsection

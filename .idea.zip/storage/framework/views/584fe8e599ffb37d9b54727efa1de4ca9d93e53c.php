<?php $__env->startSection('title', 'Tizimga kirish'); ?>

<?php $__env->startPush('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page_js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery.maskedinput@1.4.1/src/jquery.maskedinput.min.js" type="text/javascript"></script>
    <script>
        $(function() {
            $.mask.definitions['9'] = false;
            $.mask.definitions['0'] = "[0-9]";
            $("#phone").mask("00-000-00-00");
        });
    </script>
<?php $__env->stopPush(); ?>

    <?php $__env->startSection('body'); ?>

    <body class="hold-transition login-page">
    <div class="login-box">
        <!-- /.login-logo -->
        <div class="card card-outline card-primary">
            <div class="card-header text-center">
                <a href="#" class="h1"><b>Tizimga kirish</b></a>
            </div>
            <div class="card-body">

                <?php if($errors->any()): ?>
                    <script>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        toastr.error('<?php echo e($error); ?>');
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </script>
                <?php endif; ?>

                <form action="" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <div class="input-group-append">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><b>+998</b></span>
                            </div>
                        </div>
                        <input type="tel" class="form-control" id="phone" name="phone" placeholder="00-000-00-00    ">
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                        <input type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    <div class="row">
                        <!-- /.col -->
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-primary btn-block">Kirish</button>
                        </div>
                        <!-- /.col -->
                    </div>
                </form>


                <p class="mb-1">
                    <a href="#">Parolni unutdingizmi?</a>
                </p>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.login-box -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\beoo\OSPanel\OpenServer\domains\insoncj\resources\views/admin/login.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> <?php echo $__env->yieldContent('title'); ?>  </title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Page styles  -->
    <!-- jQuery -->
    <script src="<?php echo e(asset('adassets/plugins/jquery/jquery.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('page_css'); ?>
    <!-- end Page styles  -->

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('adassets/dist/css/adminlte.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/toastr/toastr.min.css')); ?>">
    <script src="<?php echo e(asset('adassets/plugins/toastr/toastr.min.js')); ?>"></script>

</head>

<?php echo $__env->yieldContent('body'); ?>

<?php echo $__env->yieldPushContent('page_js'); ?>

<?php if($errors->any()): ?>
    <script>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        toastr.error('<?php echo e($error); ?>');
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
<?php endif; ?>

<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('adassets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('adassets/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('adassets/dist/js/demo.js')); ?>"></script>

<?php if(Session::has('success_msg')): ?>
    <script>toastr.success("<?php echo e(session('success_msg')); ?>")</script>
<?php endif; ?>
<?php if(Session::has('error_msg')): ?>
    <script>toastr.error("<?php echo e(session('error_msg')); ?>")</script>
<?php endif; ?>

</html>
<?php /**PATH D:\beoo\OSPanel\OpenServer\domains\insoncj\resources\views/base/master.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', "Tahririyat a'zolari"); ?>

<?php $__env->startSection('content_name', "Tahririyat a'zolari"); ?>

<?php $__env->startSection('main_content'); ?>

    <!-- Default box -->
    <div class="card card-solid ">

        <div class="card-header text-right">
            <a href="<?php echo e(route('admin.experts.create')); ?>" class="btn btn-primary">
                + Expert qo'shish
            </a>
        </div>

        <div class="card-body pb-0 table-responsive">
            <table class="table table-bordered table-striped mb-5 text-nowrap">
                <thead>
                <tr style="border: 1px solid #333;">
                    <th style="width: 10px">#</th>
                    <th>Rasmi</th>
                    <th>F.I.SH</th>
                    <th>Lavozimi</th>
                    <th>Ish joyi</th>
                    <th>Edit | Delete</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $experts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><img src="<?php echo e(asset('images/experts/' . $expert->image)); ?>" width="80"></td>
                        <td><?php echo e($expert->fio); ?></td>
                        <td><?php echo e($expert->lavozim); ?></td>
                        <td><?php echo e($expert->ishjoyi); ?></td>
                        <td style="width: 20%">
                            <a href="<?php echo e(route('admin.experts.edit',$expert->id)); ?>" class="btn btn-warning"><i class="fa fa-pencil-alt"></i></a>
                            |
                            <form action="<?php echo e(route('admin.experts.destroy', $expert->id)); ?>" method="POST" onsubmit="return confirm('Expertni o\'chirmoqchimisiz?')" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\beoo\OSPanel\OpenServer\domains\insoncj\resources\views/admin/experts.blade.php ENDPATH**/ ?>
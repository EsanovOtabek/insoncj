<footer class="main-footer">
      <!-- Default to the left -->
      <strong>Copyright &copy; 2023 <a href="https://lifepc.uz">Esanov Otabek</a>.</strong> All rights reserved.
</footer>
<?php /**PATH D:\beoo\OSPanel\OpenServer\domains\insoncj\resources\views/base/admin_footer.blade.php ENDPATH**/ ?>
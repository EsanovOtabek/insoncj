<?php $__env->startSection('title', $news->title_uz); ?>
<?php $__env->startSection('description', "Yangilik - ". $news->title_uz); ?>
<?php $__env->startSection('og_image', asset('images/'.$news->image)); ?>

<?php $__env->startSection('body'); ?>
    <!-- Content -->
    <div class="py-3">
        <div class="container">
            <nav>
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('index')); ?>">
                            <i class="bi bi-house"></i> Bosh sahida
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">E'lonlar</li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($news->title_uz); ?></li>
                </ol>
            </nav>
        </div>
    </div>
    <hr class="m-0">
    <div class="py-5">
        <div class="container">
            <div>
                <h2 class="text-black fw-bold"><?php echo e($news->title_uz); ?></h2>
            </div>
            <small class="bg-light pt-3 gap-2 d-block d-md-flex">
                <div><span class="badge bg-danger pills text-white">NEWS</span></div>
                <div class="gap-1"><i class="bi bi-calendar"></i>  <?php echo e($news->date); ?></div>
            </small>
            <div class="pt-5">
                <div class="row">
                    <div class="col-lg-8 col-md-12">
                        <div class="gap-2">
                            <div class="col mb-5">
                                <div class="card border-0 shadow-sm overflow-hidden rounded-3">
                                    <img src="<?php echo e(asset('images/' . $news->image)); ?>" class="img-fluid rounded-3">
                                    <div class="card-body">
                                        <div class="float-end gap-3 d-flex">
                                            <div class="gap-2">
                                                <a class="text-muted"
                                                   href="https://t.me/share/url?url=http://insoncj.eo/news/<?php echo e($news->id); ?>&text=<?php echo e($news->title_uz); ?>" target="_blank">
                                                    <i class="bi bi-share"></i>
                                                    <span>Ulashish</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-4">
                                <h5 class="mb-4 text-dark"><?php echo e($news->title_uz); ?></h5>
                                <p>
                                    <?php echo e($news->text_uz); ?>

                                </p>
                            </div>


                            <hr class="m-0">
                        </div>
                    </div>

                    <div class="col-lg-4 d-none d-md-block">
                        <div class="sidebar-fixed">
                            <div class="card border-0 bg-white rounded-3 shadow-sm overflow-hidden mb-3 p-3">
                                <div class="card-body p-4">
                                    <div class="small text-muted fw-bolder fs-6">
                                        <a href="#"> <span class="badge bg-danger">Eng so'ngi e'lonlar</span></a>
                                    </div>

                                    <hr>
                                    <div class="card mb-3 border-0 w-100 rounded-3 shadow-sm overflow-hidden">
                                        <div class="row g-0">
                                            <?php $__currentLoopData = $latest6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-4">
                                                    <a href="<?php echo e(route('newsShow', $news->id)); ?>">
                                                        <img src="<?php echo e(asset('images/' . $n->image)); ?>" class="img-fluid h-100" alt="...">
                                                    </a>
                                                </div>
                                                <div class="col-8 d-flex flex-column">
                                                    <a href="<?php echo e(route('newsShow', $n->id)); ?>">

                                                        <div class="card-body p-3">
                                                            <h3 class="card-title mb-1 h5 text-dark"><?php echo e($n->title_uz); ?></h3>
                                                        </div>
                                                        <div class="card-footer mt-auto bg-white p-3">
                                                            <small class="text-muted">
                                                                <i class="bi bi-calendar"></i> <?php echo e($n->date); ?>

                                                            </small>
                                                        </div>
                                                    </a>
                                                </div>
                                                <hr class="m-0">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <hr class="mt-0">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\beoo\OSPanel\OpenServer\domains\insoncj\resources\views/web/newsShow.blade.php ENDPATH**/ ?>
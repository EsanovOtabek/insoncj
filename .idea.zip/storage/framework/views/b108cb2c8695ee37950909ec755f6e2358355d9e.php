<?php $__env->startSection('title', 'Bosh sahifa'); ?>
<?php $__env->startSection('description', "Inson kapitali va ijtimoiy rivojlanish ilmiy jurnali"); ?>
<?php $__env->startSection('og_image', ''); ?>

<?php $__env->startSection('body'); ?>
    <!-- Banner Search -->
    <?php echo $__env->make('web.web_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Sikshaa course 1st row -->
    <?php echo $__env->make('web.web_docs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sikshaa course 1st row -->
    <?php echo $__env->make('web.web_journals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sikshaa course 1st row -->
    <?php echo $__env->make('web.web_requirements', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- sections -->
    <?php echo $__env->make('web.web_ads', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- counter -->
    <?php echo $__env->make('web.web_counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page_js'); ?>
    <script>
        $('#more_btn').click(function (){

            $('#more_btn').addClass('d-none');
            $('#less_btn').removeClass('d-none');
            $('.reqd-none').removeClass('d-none');
        });

        $('#less_btn').click(function (){

            $('#more_btn').removeClass('d-none');
            $('#less_btn').addClass('d-none');
            $('.reqd-none').addClass('d-none');
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('base.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\beoo\OSPanel\OpenServer\domains\insoncj\resources\views/web/index.blade.php ENDPATH**/ ?>